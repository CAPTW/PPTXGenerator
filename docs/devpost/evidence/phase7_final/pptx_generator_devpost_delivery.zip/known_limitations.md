# Known limitations

- Windows 11, CPython 3.11, Microsoft PowerPoint COM, and Playwright Chromium are required for the canonical evidence run.
- The external CAPTW/pngtopptx SkillSet is pinned but not redistributed.
- Phase 7D fresh-clone reproduction and human feedback remain pending.
- This package is not eligible for final DevPost submission.

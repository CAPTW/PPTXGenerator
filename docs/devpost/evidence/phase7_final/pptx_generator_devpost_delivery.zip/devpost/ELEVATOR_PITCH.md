# Elevator Pitch

> DRAFT - Phase 7C release-pack candidate. Phase 7D fresh-clone proof is still required.

PPTX Generator converts a source-grounded presentation plan into an editable six-slide PowerPoint and matching HTML while preserving native text, tables, layout objects, and auditable evidence links.

Public product: **PPTX Generator**  
Internal system: **DeckCompiler**  
Tested runtime commit: `5d845d373ae2255b5d490c45ce4e3435107c3d08`  
Delivery archive transport name: `pptx_generator_devpost_delivery.zip`. Integrity is recorded in `../delivery_manifest.json` and the external package validation report.

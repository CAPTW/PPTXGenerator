# Built With

> DRAFT - Phase 7C release-pack candidate. Phase 7D fresh-clone proof is still required.

- Python 3.11
- PowerPoint COM
- Playwright Chromium
- JSON Schema Draft 2020-12
- CAPTW/pngtopptx SkillSet (external prerequisite)

Public product: **PPTX Generator**  
Internal system: **DeckCompiler**  
Tested runtime commit: `5d845d373ae2255b5d490c45ce4e3435107c3d08`  
Delivery archive transport name: `pptx_generator_devpost_delivery.zip`. Integrity is recorded in `../delivery_manifest.json` and the external package validation report.

# Architecture Overview

> DRAFT - Phase 7C release-pack candidate. Phase 7D fresh-clone proof is still required.

Source documents -> Phase 3 semantic artifacts -> frozen Phase 4 editable template specification -> external pngtopptx handoff -> deterministic PPTX/HTML reconstruction -> PowerPoint/Chromium evidence -> Composite QA -> delivery package.

Public product: **PPTX Generator**  
Internal system: **DeckCompiler**  
Tested runtime commit: `5d845d373ae2255b5d490c45ce4e3435107c3d08`  
Delivery archive transport name: `pptx_generator_devpost_delivery.zip`. Integrity is recorded in `../delivery_manifest.json` and the external package validation report.

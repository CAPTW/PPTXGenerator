# Session Provenance

> DRAFT - Phase 7C release-pack candidate. Phase 7D fresh-clone proof is still required.

No Session ID is invented or claimed. Runtime and component provenance are recorded in `../provenance/` and bound by `../delivery_manifest.json`.

Public product: **PPTX Generator**  
Internal system: **DeckCompiler**  
Tested runtime commit: `5d845d373ae2255b5d490c45ce4e3435107c3d08`  
Delivery archive transport name: `pptx_generator_devpost_delivery.zip`. Integrity is recorded in `../delivery_manifest.json` and the external package validation report.

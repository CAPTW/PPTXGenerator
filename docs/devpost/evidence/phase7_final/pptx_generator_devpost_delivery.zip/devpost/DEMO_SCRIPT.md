# Demo Script

> DRAFT - Phase 7C release-pack candidate. Phase 7D fresh-clone proof is still required.

1. Open [`../output/pptx_generator_demo.pptx`](../output/pptx_generator_demo.pptx).
2. Confirm six editable slides and native text/table objects.
3. Open [`../output/html/index.html`](../output/html/index.html).
4. Compare [`../renders/contact_sheet.png`](../renders/contact_sheet.png) with the QA evidence.

Public product: **PPTX Generator**  
Internal system: **DeckCompiler**  
Tested runtime commit: `5d845d373ae2255b5d490c45ce4e3435107c3d08`  
Delivery archive transport name: `pptx_generator_devpost_delivery.zip`. Integrity is recorded in `../delivery_manifest.json` and the external package validation report.
